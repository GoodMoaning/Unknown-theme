# Bunny-Fonts
A font collection for Bunny

## Fonts list:

### Poppins Light
- [Install link](https://raw.githubusercontent.com/Purple-EyeZ/Bunny-Fonts/main/PoppinsLight/Poppins-Light-font-snippet.json)
<details>
  <summary>Show preview</summary>
 <img src="./Screenshots/Poppins Light-portrait.png" width="300">
</details>

___

### Poppins
- [Install link](https://raw.githubusercontent.com/Purple-EyeZ/Bunny-Fonts/main/Poppins/Poppins-font-snippet.json)
<details>
  <summary>Show preview</summary>
 <img src="./Screenshots/Poppins-portrait.png" width="300">
</details>

___

### Urbanist
- [Install link](https://raw.githubusercontent.com/Purple-EyeZ/Bunny-Fonts/main/Urbanist/Urbanist-font-snippet.json)
<details>
  <summary>Show preview</summary>
 <img src="./Screenshots/Urbanist-portrait.png" width="300">
</details>

___

### Plus Jakarta Sans
- [Install link](https://raw.githubusercontent.com/Purple-EyeZ/Bunny-Fonts/main/Plus-Jakarta-Sans/Plus-Jakarta-Sans-font-snippet.json)
<details>
  <summary>Show preview</summary>
 <img src="./Screenshots/Plus Jakarta Sans-portrait.png" width="300">
</details>

___

### Gantari
- [Install link](https://raw.githubusercontent.com/Purple-EyeZ/Bunny-Fonts/main/Gantari/Gantari-font-snippet.json)
<details>
  <summary>Show preview</summary>
 <img src="./Screenshots/Gantari-portrait.png" width="300">
</details>

___

### Exo-2
- [BROKEN! DON'T USE IT] [Install link](https://raw.githubusercontent.com/Purple-EyeZ/Bunny-Fonts/main/Exo-2/Exo2-font-snippet.json)
<details>
  <summary>Show preview</summary>
 <img src="./Screenshots/Exo 2-portrait.png" width="300">
</details>

___